<template>
    <div>I'm index</div>
</template>

<script>
    export default {
        name: "Index"
    }
</script>

<style scoped>

</style>
