window.notify = function(message) {
    $.notify(message, {position: "bottom right"})
};
