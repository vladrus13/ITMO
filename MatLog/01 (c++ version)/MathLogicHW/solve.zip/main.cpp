#include "SolveE.h"

int main() {
    solve();
    return 0;
}
