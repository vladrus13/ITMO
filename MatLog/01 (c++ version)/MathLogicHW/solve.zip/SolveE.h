//
// Created by vladkuznetsov on 20.06.2020.
//

#ifndef MATHLOGICHW_SOLVEE_H
#define MATHLOGICHW_SOLVEE_H

#include <iostream>
#include <vector>
#include <algorithm>
#include "ExpressionParser.h"
#include "SolveStatus.cpp"


void get_bam(const string& edit);

void solve();

#endif //MATHLOGICHW_SOLVEE_H
